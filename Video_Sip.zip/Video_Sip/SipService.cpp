#include "SipService.h"


//����pjsip��
#pragma comment(lib, "pjlib-x86_64-x64-vc14-Release.lib")
#pragma comment(lib, "pjlib-util-x86_64-x64-vc14-Release.lib")
#pragma comment(lib, "pjmedia-x86_64-x64-vc14-Release.lib")
#pragma comment(lib, "pjsip-core-x86_64-x64-vc14-Release.lib")
#pragma comment(lib, "pjsip-ua-x86_64-x64-vc14-Release.lib")

//����ϵͳ��ͷ�ļ�
#pragma comment(lib, "ws2_32.lib")

//���������ռ�
using namespace std;

#define THIS_FILE		"SipService.cpp"

//��ʱ�����ȫ�ֱ���
struArgs* g_pArgs;


//��ʼ����������
void InitAllInfo()
{
	g_pArgs = new allArgs;
}

//��ȡIP��ַ
std::string GetLocalAddress()
{
	std::string strAddress = "";
	char strHost[1024] = { 0 };

	// get host name, if fail, SetLastError is called  
	if (SOCKET_ERROR != gethostname(strHost, sizeof(strHost)))
	{
		struct hostent* hp;
		hp = gethostbyname(strHost);
		if (hp != NULL && hp->h_addr_list[0] != NULL)
		{
			// IPv4: Address is four bytes (32-bit)  
			if (hp->h_length < 4)
				return false;

			// Convert address to . format  
			strHost[0] = 0;

			// IPv4: Create Address string  
			sprintf(strHost, "%u.%u.%u.%u",
				(UINT)(((PBYTE)hp->h_addr_list[0])[0]),
				(UINT)(((PBYTE)hp->h_addr_list[0])[1]),
				(UINT)(((PBYTE)hp->h_addr_list[0])[2]),
				(UINT)(((PBYTE)hp->h_addr_list[0])[3]));

			strAddress = strHost;
			return strAddress;
		}
	}
	else
		SetLastError(ERROR_INVALID_PARAMETER);

	return "";
}

//��strת��ΪPjStr
pj_str_t* StrToPjstr(std::string strIp)
{
	pj_str_t* pStr = new pj_str_t;
	pStr->ptr = const_cast<char*>(strIp.c_str());
	pStr->slen = (pj_ssize_t)strlen(strIp.c_str());
	return pStr;
}


//��ʼ��pjsip����
bool InitPjsipService(void* args, std::string contact, int logLevel)
{
	struArgs* ArgsInput = (struArgs*)args;
	ArgsInput->strConcat = contact;
	pj_log_set_level(logLevel);
	auto status = pj_init();
	status = pjlib_util_init();

	//��ʼ�������
	pj_caching_pool_init(&(ArgsInput->cachingPool), &pj_pool_factory_default_policy, 0);

	/*
	* Create an instance of SIP endpoint from the specified pool factory.
	* The pool factory reference then will be kept by the endpoint, so that
	* future memory allocations by SIP components will be taken from the same
	* pool factory.
	*/
	//���� endpoint,Ӧ�ó������ָ��endpointʹ�õ��ڴ�ع�����endpoint�����Լ������������ڱ��ִ��ڴ�ع�����ָ�룬���ɴ���������ͷ��ڴ��
	status = pjsip_endpt_create(&ArgsInput->cachingPool.factory, nullptr, &ArgsInput->endPoint);

	/**
	* Create and register transaction layer module to the specified endpoint.
	* @param endpt	    The endpoint instance.
	* @return	    PJ_SUCCESS on success.
	*/
	status = pjsip_tsx_layer_init_module(ArgsInput->endPoint);
	/**
	* Initialize user agent layer and register it to the specified endpoint.
	* @param endpt		The endpoint where the user agent will be registered.
	* @param prm		UA initialization parameter.
	* @return		PJ_SUCCESS on success.
	*/
	status = pjsip_ua_init_module(ArgsInput->endPoint, nullptr);

	//����һ���ڴ��
	ArgsInput->pool = pj_pool_create(&ArgsInput->cachingPool.factory, "proxyapp", 4000, 4000, nullptr);
	//pjsip_endpt_create_pool();

	//��ȡIP��ַ
	auto pjStr = StrToPjstr(ArgsInput->ipInfo);

	pj_sockaddr_in pjAddr;

	pjAddr.sin_family = pj_AF_INET();
	pj_inet_aton(pjStr, &pjAddr.sin_addr);

	auto port = ArgsInput->port;
	pjAddr.sin_port = pj_htons(static_cast<pj_uint16_t>(port));
	status = pjsip_udp_transport_start(ArgsInput->endPoint, &pjAddr, nullptr, 1, nullptr);
	if (status != PJ_SUCCESS)
		return status;

	auto realm = StrToPjstr(GetLocalAddress());
	return pjsip_auth_srv_init(ArgsInput->pool, &ArgsInput->authentication, realm, ArgsInput->lookup, 0) == PJ_SUCCESS ? true : false;
}

//��������������catelog��Ϣ
void QueryDeviceInfo(void* hangle, const string& scheme/* = "Catelog"*/)
{
	struct struArgs* pHandle = (struct struArgs*)hangle;
	char szQueryInfo[200] = { 0 };
	pj_ansi_snprintf(szQueryInfo, 200,
		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
		"<Query>\n"
		"<CmdType>%s</CmdType>\n"
		"<SN>17430</SN>\n"
		"<DeviceID>%s</DeviceID>\n"
		"</Query>\n", scheme.c_str(), pHandle->pDevInfo->UserName.c_str());
	pjsip_tx_data* tdata;
	const pjsip_method method = { PJSIP_OTHER_METHOD, { "MESSAGE", 7 } };
	auto text = StrToPjstr(string(szQueryInfo));
	pjsip_endpt_create_request(pHandle->endPoint, &method, StrToPjstr(pHandle->pDevInfo->SipIpUrl), StrToPjstr(pHandle->strConcat), StrToPjstr(pHandle->pDevInfo->SipCodeUrl),
		StrToPjstr(pHandle->strConcat), nullptr, -1, text, &tdata);
	tdata->msg->body->content_type.type = pj_str("Application");
	tdata->msg->body->content_type.subtype = pj_str("MANSCDP+xml");
	pjsip_endpt_send_request(pHandle->endPoint, tdata, -1, nullptr, nullptr);
}

//������Ӧ���ݵ��ͻ���
void Response(void* args, pjsip_rx_data* rdata, int st_code, int headType)
{
	struct struArgs* pArgsInput = (struct struArgs*) args;
	std::lock_guard<mutex> lk(pArgsInput->lock);
	pjsip_tx_data* tdata;
	pjsip_endpt_create_response(pArgsInput->endPoint, rdata, st_code, nullptr, &tdata);
	SYSTEMTIME date;
	GetLocalTime(&date);
	char szDate[1024] = { 0 };
	sprintf(szDate, "(YYYY-MM-DD HH:MM:SS): %d-%d-%d %d:%d:%d", date.wYear, date.wMonth, date.wDay, date.wHour, date.wMinute, date.wSecond);
	pj_str_t c;
	pj_str_t key;
	pjsip_hdr* hdr;
	switch (headType)
	{
	case DateHead:
		key = pj_str("Date");
		hdr = reinterpret_cast<pjsip_hdr*>(pjsip_date_hdr_create(pArgsInput->pool, &key, pj_cstr(&c, szDate)));
		pjsip_msg_add_hdr(tdata->msg, hdr);
		break;
	case AuthenHead:
		pjsip_auth_srv_challenge(&pArgsInput->authentication, nullptr, nullptr, nullptr, PJ_FALSE, tdata);
		break;
	default:
		break;
	}
	pjsip_response_addr addr;
	pjsip_get_response_addr(pArgsInput->pool, rdata, &addr);
	pjsip_endpt_send_response(pArgsInput->endPoint, &addr, tdata, nullptr, nullptr);
}

//IPHlpApi.lib;wsock32.lib;ws2_32.lib;ole32.lib;dsound.lib;

//���������ע����Ϣ������������Ӧ����Ϣ
pj_bool_t OnReceive(pjsip_rx_data* rdata)
{
	struct struArgs* pArgsInput = new struct struArgs;
	if (pArgsInput == nullptr)
		return false;
	if (rdata->msg_info.cseq->method.id == PJSIP_REGISTER_METHOD)
	{
		auto expires = static_cast<pjsip_expires_hdr*>(pjsip_msg_find_hdr(rdata->msg_info.msg, PJSIP_H_EXPIRES, nullptr));
		auto authHdr = static_cast<pjsip_authorization_hdr*>(pjsip_msg_find_hdr(rdata->msg_info.msg, PJSIP_H_AUTHORIZATION, nullptr));
		if (expires && expires->ivalue > 0)
		{
			if (authHdr)
			{
				cout << "receive register info" << endl;
				Response((void*)pArgsInput, rdata, PJSIP_SC_OK, DateHead);
				QueryDeviceInfo(rdata);
			}
			else
			{
				Response((void*)pArgsInput, rdata, PJSIP_SC_UNAUTHORIZED, AuthenHead);
			}
			return true;
		}
	}

	return false;
}

//�����ݶ�
static void on_new_session(pjsip_inv_session *inv, pjsip_event *e)
{
	PJ_UNUSED_ARG(inv);
	PJ_UNUSED_ARG(e);
}


//״̬�ı�ص�
static void on_state_changed(pjsip_inv_session *inv, pjsip_event *e)
{
	const char *who = NULL;

	PJ_UNUSED_ARG(e);

	if (inv->state == PJSIP_INV_STATE_DISCONNECTED) {
		(inv == inv_test.uas ? "Callee" : "Caller");
		return;
	}

	if (inv->state != PJSIP_INV_STATE_CONFIRMED)
		return;

	if (inv == inv_test.uas) {
		inv_test.uas_complete = PJ_TRUE;
		who = "Callee";
	}
	else if (inv == inv_test.uac) {
		inv_test.uac_complete = PJ_TRUE;
		who = "Caller";
	}
	else
		pj_assert(!"No session");

	if (inv_test.uac_complete && inv_test.uas_complete)
		inv_test.complete = PJ_TRUE;
}

/**************** UTILS ******************/
static pjmedia_sdp_session *create_sdp(pj_pool_t *pool, const char *body)
{
	pjmedia_sdp_session *sdp;
	pj_str_t dup;
	pj_status_t status;

	pj_strdup2_with_null(pool, &dup, body);
	status = pjmedia_sdp_parse(pool, dup.ptr, dup.slen, &sdp);
	pj_assert(status == PJ_SUCCESS);
	PJ_UNUSED_ARG(status);

	return sdp;
}

/**************** INVITE SESSION CALLBACKS ******************/
static void on_rx_offer(pjsip_inv_session *inv,	const pjmedia_sdp_session *offer)
{
	pjmedia_sdp_session *sdp;

	PJ_UNUSED_ARG(offer);

	sdp = create_sdp(inv->dlg->pool, oa_sdp[inv_test.oa_index].answer);
	pjsip_inv_set_sdp_answer(inv, sdp);

	if (inv_test.oa_index == inv_test.param.count - 1 &&
		inv_test.param.need_established)
	{
		jobs[job_cnt].type = ESTABLISH_CALL;
		jobs[job_cnt].who = PJSIP_ROLE_UAS;
		job_cnt++;
	}
}

/*
* Cleanup call setting flag to avoid one time flags, such as
* PJSUA_CALL_UNHOLD, PJSUA_CALL_UPDATE_CONTACT, or
* PJSUA_CALL_NO_SDP_OFFER, to be sticky (ticket #1793).
*/
static void cleanup_call_setting_flag(pjsua_call_setting *opt)
{
	opt->flag &= ~(PJSUA_CALL_UNHOLD | PJSUA_CALL_UPDATE_CONTACT |
		PJSUA_CALL_NO_SDP_OFFER | PJSUA_CALL_REINIT_MEDIA |
		PJSUA_CALL_UPDATE_VIA);
}

#if 0

/*
* Callback called by event framework when the xfer subscription state
* has changed.
*/
static void xfer_server_on_evsub_state(pjsip_evsub *sub, pjsip_event *event)
{
	PJ_UNUSED_ARG(event);

	pj_log_push_indent();

	/*
	* When subscription is terminated, clear the xfer_sub member of
	* the inv_data.
	*/
	if (pjsip_evsub_get_state(sub) == PJSIP_EVSUB_STATE_TERMINATED) {
		pjsua_call *call;

		call = (pjsua_call*)pjsip_evsub_get_mod_data(sub, pjsua_var.mod.id);
		if (!call)
			goto on_return;

		pjsip_evsub_set_mod_data(sub, pjsua_var.mod.id, NULL);
		call->xfer_sub = NULL;

		PJ_LOG(4, (THIS_FILE, "Xfer server subscription terminated"));
	}

on_return:
	pj_log_pop_indent();
}

#endif

#if 0

/*
* Follow transfer (REFER) request.
*/
static void on_call_transferred(pjsip_inv_session *inv,
	pjsip_rx_data *rdata)
{
	pj_status_t status;
	pjsip_tx_data *tdata;
	pjsua_call *existing_call;
	int new_call;
	const pj_str_t str_refer_to = { "Refer-To", 8 };
	const pj_str_t str_refer_sub = { "Refer-Sub", 9 };
	const pj_str_t str_ref_by = { "Referred-By", 11 };
	pjsip_generic_string_hdr *refer_to;
	pjsip_generic_string_hdr *refer_sub;
	pjsip_hdr *ref_by_hdr;
	pj_bool_t no_refer_sub = PJ_FALSE;
	char *uri;
	pjsua_msg_data msg_data;
	pj_str_t tmp;
	pjsip_status_code code;
	pjsip_evsub *sub;
	pjsua_call_setting call_opt;

	pj_log_push_indent();

	existing_call = (pjsua_call*)inv->dlg->mod_data[pjsua_var.mod.id];

	/* Find the Refer-To header */
	refer_to = (pjsip_generic_string_hdr*)
		pjsip_msg_find_hdr_by_name(rdata->msg_info.msg, &str_refer_to, NULL);

	if (refer_to == NULL) {
		/* Invalid Request.
		* No Refer-To header!
		*/
		//PJ_LOG(4, (THIS_FILE, "Received REFER without Refer-To header!"));
		pjsip_dlg_respond(inv->dlg, rdata, 400, NULL, NULL, NULL);
		goto on_return;
	}

	/* Find optional Refer-Sub header */
	refer_sub = (pjsip_generic_string_hdr*)
		pjsip_msg_find_hdr_by_name(rdata->msg_info.msg, &str_refer_sub, NULL);

	if (refer_sub) {
		if (pj_strnicmp2(&refer_sub->hvalue, "true", 4) != 0)
			no_refer_sub = PJ_TRUE;
	}

	/* Find optional Referred-By header (to be copied onto outgoing INVITE
	* request.
	*/
	ref_by_hdr = (pjsip_hdr*)
		pjsip_msg_find_hdr_by_name(rdata->msg_info.msg, &str_ref_by,
		NULL);

	/* Notify callback */
	code = PJSIP_SC_ACCEPTED;
	if (pjsua_var.ua_cfg.cb.on_call_transfer_request) {
		(*pjsua_var.ua_cfg.cb.on_call_transfer_request)(existing_call->index,
			&refer_to->hvalue,
			&code);
	}

	cleanup_call_setting_flag(&existing_call->opt);
	call_opt = existing_call->opt;
	if (pjsua_var.ua_cfg.cb.on_call_transfer_request2) {
		(*pjsua_var.ua_cfg.cb.on_call_transfer_request2)(existing_call->index,
			&refer_to->hvalue,
			&code,
			&call_opt);
	}

	if (code < 200)
		code = PJSIP_SC_ACCEPTED;
	if (code >= 300) {
		/* Application rejects call transfer request */
		pjsip_dlg_respond(inv->dlg, rdata, code, NULL, NULL, NULL);
		goto on_return;
	}

	PJ_LOG(3, (THIS_FILE, "Call to %.*s is being transferred to %.*s",
		(int)inv->dlg->remote.info_str.slen,
		inv->dlg->remote.info_str.ptr,
		(int)refer_to->hvalue.slen,
		refer_to->hvalue.ptr));

	if (no_refer_sub) {
		/*
		* Always answer with 2xx.
		*/
		pjsip_tx_data *tdata2;
		const pj_str_t str_false = { "false", 5 };
		pjsip_hdr *hdr;

		status = pjsip_dlg_create_response(inv->dlg, rdata, code, NULL,
			&tdata2);
		if (status != PJ_SUCCESS) {
			pjsua_perror(THIS_FILE, "Unable to create 2xx response to REFER",
				status);
			goto on_return;
		}

		/* Add Refer-Sub header */
		hdr = (pjsip_hdr*)
			pjsip_generic_string_hdr_create(tdata2->pool, &str_refer_sub,
			&str_false);
		pjsip_msg_add_hdr(tdata2->msg, hdr);


		/* Send answer */
		status = pjsip_dlg_send_response(inv->dlg, pjsip_rdata_get_tsx(rdata),
			tdata2);
		if (status != PJ_SUCCESS) {
			pjsua_perror(THIS_FILE, "Unable to create 2xx response to REFER",
				status);
			goto on_return;
		}

		/* Don't have subscription */
		sub = NULL;

	}
	else {
		struct pjsip_evsub_user xfer_cb;
		pjsip_hdr hdr_list;

		/* Init callback */
		pj_bzero(&xfer_cb, sizeof(xfer_cb));
		xfer_cb.on_evsub_state = &xfer_server_on_evsub_state;

		/* Init additional header list to be sent with REFER response */
		pj_list_init(&hdr_list);

		/* Create transferee event subscription */
		status = pjsip_xfer_create_uas(inv->dlg, &xfer_cb, rdata, &sub);
		if (status != PJ_SUCCESS) {
			pjsua_perror(THIS_FILE, "Unable to create xfer uas", status);
			pjsip_dlg_respond(inv->dlg, rdata, 500, NULL, NULL, NULL);
			goto on_return;
		}

		/* If there's Refer-Sub header and the value is "true", send back
		* Refer-Sub in the response with value "true" too.
		*/
		if (refer_sub) {
			const pj_str_t str_true = { "true", 4 };
			pjsip_hdr *hdr;

			hdr = (pjsip_hdr*)
				pjsip_generic_string_hdr_create(inv->dlg->pool,
				&str_refer_sub,
				&str_true);
			pj_list_push_back(&hdr_list, hdr);

		}

		/* Accept the REFER request, send 2xx. */
		pjsip_xfer_accept(sub, rdata, code, &hdr_list);

		/* Create initial NOTIFY request */
		status = pjsip_xfer_notify(sub, PJSIP_EVSUB_STATE_ACTIVE,
			100, NULL, &tdata);
		if (status != PJ_SUCCESS) {
			pjsua_perror(THIS_FILE, "Unable to create NOTIFY to REFER",
				status);
			goto on_return;
		}

		/* Send initial NOTIFY request */
		status = pjsip_xfer_send_request(sub, tdata);
		if (status != PJ_SUCCESS) {
			pjsua_perror(THIS_FILE, "Unable to send NOTIFY to REFER", status);
			goto on_return;
		}
	}

	/* We're cheating here.
	* We need to get a null terminated string from a pj_str_t.
	* So grab the pointer from the hvalue and NULL terminate it, knowing
	* that the NULL position will be occupied by a newline.
	*/
	uri = refer_to->hvalue.ptr;
	uri[refer_to->hvalue.slen] = '\0';

	/* Init msg_data */
	pjsua_msg_data_init(&msg_data);

	/* If Referred-By header is present in the REFER request, copy this
	* to the outgoing INVITE request.
	*/
	if (ref_by_hdr != NULL) {
		pjsip_hdr *dup = (pjsip_hdr*)
			pjsip_hdr_clone(rdata->tp_info.pool, ref_by_hdr);
		pj_list_push_back(&msg_data.hdr_list, dup);
	}

	/* Now make the outgoing call. */
	tmp = pj_str(uri);
	status = pjsua_call_make_call(existing_call->acc_id, &tmp, &call_opt,
		existing_call->user_data, &msg_data,
		&new_call);
	if (status != PJ_SUCCESS) {

		/* Notify xferer about the error (if we have subscription) */
		if (sub) {
			status = pjsip_xfer_notify(sub, PJSIP_EVSUB_STATE_TERMINATED,
				500, NULL, &tdata);
			if (status != PJ_SUCCESS) {
				pjsua_perror(THIS_FILE, "Unable to create NOTIFY to REFER",
					status);
				goto on_return;
			}
			status = pjsip_xfer_send_request(sub, tdata);
			if (status != PJ_SUCCESS) {
				pjsua_perror(THIS_FILE, "Unable to send NOTIFY to REFER",
					status);
				goto on_return;
			}
		}
		goto on_return;
	}

	if (sub) {
		/* Put the server subscription in inv_data.
		* Subsequent state changed in pjsua_inv_on_state_changed() will be
		* reported back to the server subscription.
		*/
		pjsua_var.calls[new_call].xfer_sub = sub;

		/* Put the invite_data in the subscription. */
		pjsip_evsub_set_mod_data(sub, pjsua_var.mod.id,
			&pjsua_var.calls[new_call]);
	}

on_return:
	pj_log_pop_indent();
}

#endif

/*
* Disconnect call upon error.
*/
static void call_disconnect(pjsip_inv_session *inv,	int code)
{
	pjsip_tx_data *tdata;
	pj_status_t status;

	status = pjsip_inv_end_session(inv, code, NULL, &tdata);
	if (status != PJ_SUCCESS)
		return;

#if DISABLED_FOR_TICKET_1185
	pjsua_call *call;

	/* Add SDP in 488 status */
	call = (pjsua_call*)inv->dlg->mod_data[pjsua_var.mod.id];

	if (call && call->tp && tdata->msg->type == PJSIP_RESPONSE_MSG &&
		code == PJSIP_SC_NOT_ACCEPTABLE_HERE)
	{
		pjmedia_sdp_session *local_sdp;
		pjmedia_transport_info ti;

		pjmedia_transport_info_init(&ti);
		pjmedia_transport_get_info(call->med_tp, &ti);
		status = pjmedia_endpt_create_sdp(pjsua_var.med_endpt, tdata->pool,
			1, &ti.sock_info, &local_sdp);
		if (status == PJ_SUCCESS) {
			pjsip_create_sdp_body(tdata->pool, local_sdp,
				&tdata->msg->body);
		}
	}
#endif

	pjsip_inv_send_msg(inv, tdata);
}


void pjsua_call_on_tsx_state_changed(pjsip_inv_session* inv, pjsip_transaction* tsx, pjsip_event* e)
{

}

#if 0
static void pjsua_call_on_tsx_state_changed(pjsip_inv_session *inv,
	pjsip_transaction *tsx,
	pjsip_event *e)
{
	pjsua_call *call;

	pj_log_push_indent();

	call = (pjsua_call*)inv->dlg->mod_data[pjsua_var.mod.id];

	if (call == NULL)
		goto on_return;

	if (call->inv == NULL) {
		/* Call has been disconnected. */
		goto on_return;
	}

	/* https://trac.pjsip.org/repos/ticket/1452:
	*    If a request is retried due to 401/407 challenge, don't process the
	*    transaction first but wait until we've retried it.
	*/
	if (tsx->role == PJSIP_ROLE_UAC &&
		(tsx->status_code == 401 || tsx->status_code == 407) &&
		tsx->last_tx && tsx->last_tx->auth_retry)
	{
		goto on_return;
	}

	/* Notify application callback first */
	if (pjsua_var.ua_cfg.cb.on_call_tsx_state) {
		(*pjsua_var.ua_cfg.cb.on_call_tsx_state)(call->index, tsx, e);
	}

	if (tsx->role == PJSIP_ROLE_UAS &&
		tsx->state == PJSIP_TSX_STATE_TRYING &&
		pjsip_method_cmp(&tsx->method, pjsip_get_refer_method()) == 0)
	{
		/*
		* Incoming REFER request.
		*/
		on_call_transferred(call->inv, e->body.tsx_state.src.rdata);

	}
	else if (tsx->role == PJSIP_ROLE_UAS &&
		tsx->state == PJSIP_TSX_STATE_TRYING &&
		pjsip_method_cmp(&tsx->method, &pjsip_message_method) == 0)
	{
		/*
		* Incoming MESSAGE request!
		*/
		pjsip_rx_data *rdata;
		pjsip_accept_hdr *accept_hdr;

		rdata = e->body.tsx_state.src.rdata;

		/* Request MUST have message body, with Content-Type equal to
		* "text/plain".
		*/
		if (pjsua_im_accept_pager(rdata, &accept_hdr) == PJ_FALSE) {

			pjsip_hdr hdr_list;

			pj_list_init(&hdr_list);
			pj_list_push_back(&hdr_list, accept_hdr);

			pjsip_dlg_respond(inv->dlg, rdata, PJSIP_SC_NOT_ACCEPTABLE_HERE,
				NULL, &hdr_list, NULL);
			goto on_return;
		}

		/* Respond with 200 first, so that remote doesn't retransmit in case
		* the UI takes too long to process the message.
		*/
		pjsip_dlg_respond(inv->dlg, rdata, 200, NULL, NULL, NULL);

		/* Process MESSAGE request */
		pjsua_im_process_pager(call->index, &inv->dlg->remote.info_str,
			&inv->dlg->local.info_str, rdata);

	}
	else if (tsx->role == PJSIP_ROLE_UAC &&
		pjsip_method_cmp(&tsx->method, &pjsip_message_method) == 0)
	{
		/* Handle outgoing pager status */
		if (tsx->status_code >= 200) {
			pjsua_im_data *im_data;

			im_data = (pjsua_im_data*)tsx->mod_data[pjsua_var.mod.id];
			/* im_data can be NULL if this is typing indication */

			if (im_data && pjsua_var.ua_cfg.cb.on_pager_status) {
				pjsua_var.ua_cfg.cb.on_pager_status(im_data->call_id,
					&im_data->to,
					&im_data->body,
					im_data->user_data,
					(pjsip_status_code)
					tsx->status_code,
					&tsx->status_text);
			}
		}
	}
	else if (tsx->role == PJSIP_ROLE_UAC &&
		pjsip_method_cmp(&tsx->method, &pjsip_invite_method) == 0 &&
		tsx->state >= PJSIP_TSX_STATE_COMPLETED &&
		e->body.tsx_state.prev_state < PJSIP_TSX_STATE_COMPLETED &&
		(!PJSIP_IS_STATUS_IN_CLASS(tsx->status_code, 300) &&
		tsx->status_code != 401 && tsx->status_code != 407 &&
		tsx->status_code != 422))
	{
		if (tsx->status_code / 100 == 2) {
			/* If we have sent CANCEL and the original INVITE returns a 2xx,
			* we then send BYE.
			*/
			if (call->hanging_up) {
				PJ_LOG(3, (THIS_FILE, "Unsuccessful in cancelling the original "
					"INVITE for call %d due to %d response, sending BYE "
					"instead", call->index, tsx->status_code));
				call_disconnect(call->inv, PJSIP_SC_OK);
			}
		}
		else {
			/* Monitor the status of call hold/unhold request */
			if (tsx->last_tx == (pjsip_tx_data*)call->hold_msg) {
				/* Outgoing call hold failed */
				call->local_hold = PJ_FALSE;
				PJ_LOG(3, (THIS_FILE, "Error putting call %d on hold "
					"(reason=%d)", call->index, tsx->status_code));
			}
			else if (call->opt.flag & PJSUA_CALL_UNHOLD) {
				/* Call unhold failed */
				call->local_hold = PJ_TRUE;
				PJ_LOG(3, (THIS_FILE, "Error releasing hold on call %d "
					"(reason=%d)", call->index, tsx->status_code));
			}
		}

		if (tsx->last_tx == (pjsip_tx_data*)call->hold_msg) {
			call->hold_msg = NULL;
		}

		if (tsx->status_code / 100 != 2 ||
			((call->opt.flag & PJSUA_CALL_NO_SDP_OFFER) == 0 &&
			!call->med_update_success))
		{
			/* Either we get non-2xx or media update failed,
			* clean up provisional media.
			*/
			pjsua_media_prov_clean_up(call->index);
		}
	}
	else if (tsx->role == PJSIP_ROLE_UAC &&
		pjsip_method_cmp(&tsx->method, &pjsip_update_method) == 0 &&
		tsx->state >= PJSIP_TSX_STATE_COMPLETED &&
		e->body.tsx_state.prev_state < PJSIP_TSX_STATE_COMPLETED &&
		(!PJSIP_IS_STATUS_IN_CLASS(tsx->status_code, 300) &&
		tsx->status_code != 401 && tsx->status_code != 407 &&
		tsx->status_code != 422))
	{
		if (tsx->status_code / 100 != 2 ||
			((call->opt.flag & PJSUA_CALL_NO_SDP_OFFER) == 0 &&
			!call->med_update_success))
		{
			/* Either we get non-2xx or media update failed,
			* clean up provisional media.
			*/
			pjsua_media_prov_clean_up(call->index);
		}
	}
	else if (tsx->role == PJSIP_ROLE_UAS &&
		tsx->state == PJSIP_TSX_STATE_TRYING &&
		pjsip_method_cmp(&tsx->method, &pjsip_info_method) == 0)
	{
		/*
		* Incoming INFO request for media control.
		*/
		const pj_str_t STR_APPLICATION = { "application", 11 };
		const pj_str_t STR_MEDIA_CONTROL_XML = { "media_control+xml", 17 };
		pjsip_rx_data *rdata = e->body.tsx_state.src.rdata;
		pjsip_msg_body *body = rdata->msg_info.msg->body;

		if (body && body->len &&
			pj_stricmp(&body->content_type.type, &STR_APPLICATION) == 0 &&
			pj_stricmp(&body->content_type.subtype, &STR_MEDIA_CONTROL_XML) == 0)
		{
			pjsip_tx_data *tdata;
			pj_str_t control_st;
			pj_status_t status;

			/* Apply and answer the INFO request */
			pj_strset(&control_st, (char*)body->data, body->len);
			status = pjsua_media_apply_xml_control(call->index, &control_st);
			if (status == PJ_SUCCESS) {
				status = pjsip_endpt_create_response(tsx->endpt, rdata,
					200, NULL, &tdata);
				if (status == PJ_SUCCESS)
					status = pjsip_tsx_send_msg(tsx, tdata);
			}
			else {
				status = pjsip_endpt_create_response(tsx->endpt, rdata,
					400, NULL, &tdata);
				if (status == PJ_SUCCESS)
					status = pjsip_tsx_send_msg(tsx, tdata);
			}
		}
	}

on_return:
	pj_log_pop_indent();
}

#endif

static void on_create_offer(pjsip_inv_session *inv,
	pjmedia_sdp_session **p_offer)
{
	PJ_UNUSED_ARG(inv);
	PJ_UNUSED_ARG(p_offer);

	pj_assert(!"Should not happen");
}

//��������Ϣ��Ϊ��������pjsip��������
bool InitServer(void* pHandle, std::string concat, int logLevel)
{
	struArgs* pInput = (struArgs*)pHandle;
	bool ret = false;
	pjsip_module* mainModule = nullptr;
	if (!mainModule)
	{
		ret = InitPjsipService((void*)pInput, concat, logLevel);
		if (!ret) return ret;
	}
	pjsip_module module =
	{
		nullptr, nullptr,
		{ "MainModule", 10 },
		-1,
		PJSIP_MOD_PRIORITY_APPLICATION,
		nullptr,
		nullptr,
		nullptr,
		nullptr,
		nullptr,
		OnReceive,
		nullptr,
		nullptr,
		nullptr,
	};

	mainModule = &module;
	/**
	* This structure contains callbacks to be registered by application to
	* receieve notifications from the framework about various events in
	* the invite session.
	*/
	//�ṹ��������ָ��,��Щָ�뽫��Ӧ��ע�ᵽinvite usageģ����������invite�Ự�¼���֪ͨ
	pjsip_inv_callback callback;
	pj_bzero(&callback, sizeof(callback));
	callback.on_state_changed = &on_state_changed;
	callback.on_new_session = &on_new_session;
	callback.on_tsx_state_changed = &pjsua_call_on_tsx_state_changed;
	callback.on_rx_offer = &on_rx_offer;
	//callback.on_rx_reinvite = &on_rx_reinvite;
	callback.on_create_offer = &on_create_offer;
	//callback.on_send_ack = &onSendAck;
	ret = pjsip_inv_usage_init(pInput->endPoint, &callback);
	if (!ret)return ret;

	ret = pjsip_endpt_register_module(pInput->endPoint, mainModule);
	if (!ret) return ret;

	//����workthread,��ʱ�������ˣ�����Ϊʲô
	return false;
}

//������Ƶ����
bool InviteVideo(pjsip_dialog* dlg, MediaContext mediaContext, std::string sdp)
{
	pjsip_inv_session *inv;
	if (PJ_SUCCESS != pjsip_inv_create_uac(dlg, nullptr, 0, &inv)) return false;
	pjsip_tx_data *tdata;
	if (PJ_SUCCESS != pjsip_inv_invite(inv, &tdata)) return false;
	pjsip_media_type type;
	type.type = pj_str("application");
	type.subtype = pj_str("sdp");
	auto text = pj_str(const_cast<char *>(sdp.c_str()));
	try
	{
		tdata->msg->body = pjsip_msg_body_create(g_pArgs->pool, &type.type, &type.subtype, &text);

		auto hName = pj_str("Subject");
		//auto subjectUrl = mediaContext.strDevID + ":" + SiralNum + "," + GetInstance().GetCode() + ":" + SiralNum;
		auto subjectUrl = mediaContext.strDevID;
		auto hValue = pj_str(const_cast<char*>(subjectUrl.c_str()));
		auto hdr = pjsip_generic_string_hdr_create(g_pArgs->pool, &hName, &hValue);
		pjsip_msg_add_hdr(tdata->msg, reinterpret_cast<pjsip_hdr*>(hdr));
		pjsip_inv_send_msg(inv, tdata);
	}
	catch (...)
	{
	}
	return true;
}

//���������յ�catalog��Ϣ�󣬽����������Ϣ��Ȼ���ִSDP,������Ƶ��Ϣ
static std::string createSDP(MediaContext& mediaContext)
{
	char str[500] = { 0 };
	pj_ansi_snprintf(str, 500,
		"v=0\n"
		"o=%s 0 0 IN IP4 %s\n"
		"s=Play\n"
		"c=IN IP4 %s\n"
		"t=0 0\n"
		"m=video %d RTP/AVP 96 98 97\n"
		"a=recvonly\n"
		"a=rtpmap:96 PS/90000\n"
		"a=rtpmap:98 H264/90000\n"
		"a=rtpmap:97 MPEG4/90000\n"
		"y=0100000001\n",
		mediaContext.strDevID.c_str(),
		mediaContext.strRevIp.c_str(),
		mediaContext.strRevIp.c_str(),
		mediaContext.nPort
		);
	return str;
}

#if 0

//������������������ص�catalog��Ϣ
bool OnReceiveCat(pjsip_rx_data* rdata)
{
	if (rdata->msg_info.cseq->method.id == PJSIP_OTHER_METHOD)
	{
		CGXmlParser xmlParser(context.GetMessageBody(rdata));
		CGDynamicStruct dynamicStruct;
		dynamicStruct.Set(xmlParser.GetXml());

		auto cmd = xmlParser.GetXml()->firstChild()->nodeName();
		auto cmdType = dynamicStruct.Get<std::string>("CmdType");
		if (cmdType != "Catalog") return false;

		auto DeviceID = dynamicStruct.Get<std::string>("DeviceID");

		Vector deviceList = dynamicStruct.Get<Vector>("DeviceList");

		for (auto& x : deviceList)
		{
			CGCatalogInfo devinfo;
			try
			{
				devinfo.PlatformAddr = rdata->pkt_info.src_name;
				devinfo.PlatformPort = rdata->pkt_info.src_port;

				devinfo.Address = x["Address"].convert<string>();
				devinfo.Name = WstringToString(x["Name"].convert<wstring>());
				devinfo.Manufacturer = x["Manufacturer"].convert<string>();
				devinfo.Model = x["Model"].convert<string>();
				devinfo.Owner = x["Owner"].convert<string>();
				devinfo.Civilcode = x["CivilCode"].convert<string>();
				devinfo.Registerway = x["RegisterWay"].convert<int>();
				devinfo.Secrecy = x["Secrecy"].convert<int>();
				//devinfo.IPAddress = x["IPAddress"].convert<string>();
				devinfo.DeviceID = x["DeviceID"].convert<string>();
				devinfo.Status = x["Status"].convert<string>();
			}
			catch (...)
			{
				//continue;
			}
			if (callback)
			{
				callback(user, &devinfo);
			}
			//SipControlModule::GetInstance().CatalogCallBack(devinfo);
		}

		Response((void*)g_pArgs, rdata, PJSIP_SC_OK, NoHead);
		return true;
}

#endif